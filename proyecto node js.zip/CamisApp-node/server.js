const express = require('express');
const path = require('path');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Sample dataset (same as frontend)
const products = [
  {id:1,name:'Camiseta A',size:['S','M'],price:12.99,created:'2025-08-01',color:'Blanco'},
  {id:2,name:'Camiseta B',size:['M','L'],price:19.50,created:'2025-09-15',color:'Negro'},
  {id:3,name:'Camiseta C',size:['L','XL'],price:9.99,created:'2025-07-22',color:'Rojo'},
  {id:4,name:'Camiseta D',size:['S','M','L'],price:25.00,created:'2025-10-02',color:'Azul'},
  {id:5,name:'Camiseta E',size:['M'],price:15.75,created:'2025-06-10',color:'Verde'},
  {id:6,name:'Camiseta F',size:['S','L'],price:29.00,created:'2025-10-20',color:'Amarillo'},
  {id:7,name:'Camiseta G',size:['XL'],price:8.50,created:'2025-05-11',color:'Negro'},
  {id:8,name:'Camiseta H',size:['M','L'],price:13.20,created:'2025-09-01',color:'Blanco'}
];

// API endpoints
app.get('/api/products', (req, res) => {
  // optional filters: q, size, sort
  let result = products.slice();
  const q = (req.query.q || '').toLowerCase();
  const size = req.query.size || '';
  const sort = req.query.sort || '';
  if(q) result = result.filter(p => p.name.toLowerCase().includes(q));
  if(size) result = result.filter(p => p.size.includes(size));
  if(sort === 'price-asc') result.sort((a,b)=> a.price-b.price);
  if(sort === 'price-desc') result.sort((a,b)=> b.price-a.price);
  if(sort === 'new') result.sort((a,b)=> new Date(b.created)-new Date(a.created));
  res.json(result);
});

app.get('/api/products/:id', (req, res) => {
  const id = Number(req.params.id);
  const p = products.find(x => x.id === id);
  if(!p) return res.status(404).json({error:'Producto no encontrado'});
  res.json(p);
});

// serve index.html for all other routes (SPA-friendly)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, ()=> console.log(`CamisApp-node listening on http://localhost:${PORT}`));
