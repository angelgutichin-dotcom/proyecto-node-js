# CamisApp-node

Entrega proyecto Node.js para Mario Vargas Montes — 9 sept (entrega funcional)

## Qué incluye
- `server.js` — Servidor Express que sirve los archivos estáticos y expone la API:
  - `GET /api/products` — lista de productos (soporta query params: q, size, sort)
  - `GET /api/products/:id` — detalle por id
- `public/` — Frontend estático (index.html, resultados.html, productos.html, perfil.html, styles.css, script.js)
- `package.json` — dependencias y scripts

## Cómo ejecutar localmente
1. Tener Node.js instalado (versión 14+).
2. Desde la carpeta del proyecto ejecutar:
```bash
npm install
npm start
```
3. Abrir en el navegador `http://localhost:3000`

## Enlace a GitHub (sugerencia)
1. Crear un repo en GitHub llamado `CamisApp-node`.
2. Subir todos los archivos y pegar el enlace del repositorio en la entrega para el profesor.

## Notas para la entrega
- El proyecto es funcional y probado localmente.
- Puedes desplegarlo en Heroku, Render o Railway si deseas un enlace público.
- Si quieres, yo puedo generar el README final con tu nombre y el enlace al repo listo para pegar en la entrega.
