// Menu toggle
document.addEventListener('click', function(e){
  const toggle = document.getElementById('nav-toggle');
  const nav = document.getElementById('nav');
  if(!toggle) return;
  if(e.target === toggle){
    nav.classList.toggle('show');
  }
});

async function fetchProducts(queryParams=''){
  try{
    const res = await fetch('/api/products' + queryParams);
    if(!res.ok) throw new Error('API error');
    return await res.json();
  }catch(e){
    console.error(e);
    return [];
  }
}

function placeholderDataURI(text){
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='600' height='400'><rect width='100%' height='100%' fill='%23e9eefb'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-size='28' fill='%230b74ff' font-family='Arial, sans-serif'>${text}</text></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

function renderProducts(list, containerId, page=1, perPage=6){
  const container = document.getElementById(containerId);
  if(!container) return;
  container.innerHTML = '';
  const start = (page-1)*perPage;
  const paginated = list.slice(start, start+perPage);
  paginated.forEach(p => {
    const div = document.createElement('div');
    div.className = 'product';
    div.innerHTML = `
      <img src="${placeholderDataURI(p.name)}" alt="${p.name}">
      <div><strong>${p.name}</strong></div>
      <div>Tallas: ${p.size.join(', ')}</div>
      <div class="price">₡ ${p.price.toFixed(2)}</div>
      <div style="margin-top:auto"><button class="btn" onclick="alert('Ver ${p.name}')">Ver</button></div>
    `;
    container.appendChild(div);
  });
  // pagination
  const totalPages = Math.max(1, Math.ceil(list.length / perPage));
  const pagDiv = document.getElementById('pagination');
  if(pagDiv){
    pagDiv.innerHTML = '';
    for(let i=1;i<=totalPages;i++){
      const b = document.createElement('button');
      b.className = 'page-btn' + (i===page?' active':'');
      b.textContent = i;
      b.onclick = ()=> renderProducts(list, containerId, i, perPage);
      pagDiv.appendChild(b);
    }
  }
}

async function applyFiltersAndRender(){
  const search = document.getElementById('search') ? document.getElementById('search').value.trim().toLowerCase() : '';
  const size = document.getElementById('filter-size') ? document.getElementById('filter-size').value : '';
  const sort = document.getElementById('sort') ? document.getElementById('sort').value : 'default';
  let qs = '?';
  if(search) qs += 'q=' + encodeURIComponent(search) + '&';
  if(size) qs += 'size=' + encodeURIComponent(size) + '&';
  if(sort && sort!=='default') qs += 'sort=' + encodeURIComponent(sort) + '&';
  const products = await fetchProducts(qs);
  renderProducts(products, 'results', 1, 6);
  renderProducts(products, 'product-grid', 1, 8);
}

// Wire controls
document.addEventListener('DOMContentLoaded', ()=>{
  applyFiltersAndRender();
  const inputs = ['search','filter-size','sort'];
  inputs.forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.addEventListener('input', applyFiltersAndRender);
  });
});